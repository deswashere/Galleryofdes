import { useState } from 'react'
import { motion } from 'framer-motion'

export default function GallerySite() {
  const [page, setPage] = useState('intro')

  const artworks = [
    { title: 'Blue Forms', src: '/artworks/blue-forms.png', description: 'A study of depth and repetition through cool tones and minimal geometry.' },
    { title: 'Red Solids', src: '/artworks/red-solids.png', description: 'Contrasting geometric precision and warmth, evoking silent intensity.' }
  ]

  if (page === 'intro') {
    return (
      <div className='min-h-screen flex flex-col items-center justify-center text-center p-6'>
        <motion.h1 initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }} className='text-5xl font-bold mb-4'>
          Desmond Gairai
        </motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className='text-xl max-w-xl'>
          Welcome to my digital gallery — a collection of structured emotion and abstract precision.
        </motion.p>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className='mt-8 flex gap-4'>
          <button onClick={() => setPage('gallery')} className='bg-white text-black px-6 py-2 rounded hover:bg-gray-300'>
            Enter Gallery
          </button>
          <a href='https://www.instagram.com/wof_inc' target='_blank' rel='noopener noreferrer'>
            <button className='border border-white px-6 py-2 rounded hover:bg-white hover:text-black'>@wof_inc</button>
          </a>
        </motion.div>
      </div>
    )
  }

  return (
    <div className='min-h-screen bg-neutral-900 text-white p-8'>
      <header className='flex justify-between items-center mb-12'>
        <h1 className='text-3xl font-bold'>Desmond Gairai — Digital Gallery</h1>
        <button onClick={() => setPage('intro')} className='border px-4 py-2 rounded'>Back</button>
      </header>
      <div className='grid md:grid-cols-2 gap-10'>
        {artworks.map((art, i) => (
          <motion.div key={i} whileHover={{ scale: 1.03 }}>
            <div className='overflow-hidden bg-neutral-800 rounded-2xl shadow-lg'>
              <img src={art.src} alt={art.title} className='w-full h-80 object-cover' />
              <div className='p-6'>
                <h2 className='text-2xl font-semibold mb-2'>{art.title}</h2>
                <p className='text-gray-400 text-sm'>{art.description}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      <footer className='text-center mt-16 text-gray-500 text-sm'>
        © {new Date().getFullYear()} Desmond Gairai — Follow me on <a href='https://www.instagram.com/wof_inc' className='underline'>@wof_inc</a>
      </footer>
    </div>
  )
}
